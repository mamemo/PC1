from .ia.pc1.g07 import set_semilla, generar_muestra_pais, generar_muestra_provincia
