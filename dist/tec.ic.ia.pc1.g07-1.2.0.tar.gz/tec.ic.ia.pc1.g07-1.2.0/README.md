# PC1
Este repositorio contiene los datos para el proyecto corto 1 del curso de Inteligencia Artificial. Se encarga de generar muestras a partir de la poblacion de Costa Rica para las votaciones presidenciales.
